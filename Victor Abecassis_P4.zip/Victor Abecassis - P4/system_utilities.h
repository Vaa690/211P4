#ifndef system_utilities
#define system_utilities

int parseCommandLine(char cline[], char *tklist[]);


#endif